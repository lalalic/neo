# DevMacBridge federated MCP UI resource fallback

This archive preserves the exact patch submitted upstream as:

- upstream repository: `alexanderradahl/mac-developer-bridge`
- upstream PR: `#17` — `Proxy federated MCP resources for app UIs`
- base commit: `fea70d1a3c5524164f2159f6063ba685fef91324`
- patch commit: `c6570c7f85d8dca235ebf6ccf8d657e8d2f5282f`

Purpose: proxy child MCP `resources/list` and `resources/read` plus UI resource metadata through DevMacBridge, so federated tools such as Neo `events__progress` can render their MCP App UI instead of degrading to text-only tool results.

The patch was validated with:

- `npm run check`
- `node tests/federation.mjs`

Apply only when the installed upstream does not already contain equivalent resource-federation support. Prefer upstream code when PR #17 or an equivalent implementation has been merged.
